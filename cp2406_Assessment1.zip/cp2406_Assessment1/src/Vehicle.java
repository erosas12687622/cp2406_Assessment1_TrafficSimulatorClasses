//public class Vehicle {

   //String road;

class Vehicle {
   public String brand = "Ford";
    int position;
}

class Car extends Vehicle{
    int len = 2;
    int height= 1;
    public Object modelName;
    public Object speed;
    public Object road;

    public static void main(String[] args) {
        Car car = new Car();{

        }
        car.honk();
        {
            System.out.println("Toot, toot!");
        }

        car.speed();{

        }

        car.move();{

        }

        System.out.println(myCar.brand);
    }
}

class Bike extends Vehicle{

    private Object car;
    int len = len(car)/2;
    int height= 1;
    public Object modelName;
    public Object speed;
    public Object road;

    public static void main(String[] args) {
        Bike myBike = new Bike();{

        }
        myBike.honk();
        {
            System.out.println("Beep, Beep!");
        }

        myBike.speed();{

        }

        myBike.move();{

        }

        System.out.println(myBike.brand);
    }

    private void move() {
    }

    private void speed() {
    }

    private void honk() {
    }
}

class Bus extends Vehicle{
    private Object car;
    int len = len(car)*3;
    int height= 1;
    public Object modelName;
    public Object speed;
    public Object road;
    public static void main(String[] args) {
        Bus myBus = new Bus();{

        }
        myBus.honk();
        {
            System.out.println("HONK, HONK!");
        }

        myBus.speed();{

        }

        myBus.move();{

        }

        System.out.println(myBus.brand);
    }

    private void move() {
    }

    private void speed() {
    }

    private void honk() {
    }
}