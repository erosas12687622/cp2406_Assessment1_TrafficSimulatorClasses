import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class VehicleTest {
    @Test
    void testDefault(){
        Car myCar;
        myCar = new Car();
        assertEquals(:null, myCar.modelName);
        assertEquals(:null, myCar.speed);
        assertEquals(:null, myCar.position);
        assertEquals(:null, myCar.road);
    }

    private void assertEquals(null, Car myCar) {
    }

}