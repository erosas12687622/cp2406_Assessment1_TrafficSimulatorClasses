public class Car extends Vehicle {
    int len = 2;
    int height= 1;
    public Object modelName;
    public Object speed;
    public Object road;


    private void honk() {
    }

    private void move() {
    }

    private void speed() {
    }
}
